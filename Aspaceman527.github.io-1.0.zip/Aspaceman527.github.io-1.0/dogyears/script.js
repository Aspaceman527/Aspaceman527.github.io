var myAge = document.getElementById("Age");
//age
let earlyYears = 2;
earlyYears *= 10.5;
let laterYears = myAge - 2;
laterYears *= 4;
var dogeYears = earlyYears + laterYears;
window.alert(`your age in dog years is ${dogeYears} years old`)
/*
copyright Aspaceman527
*/

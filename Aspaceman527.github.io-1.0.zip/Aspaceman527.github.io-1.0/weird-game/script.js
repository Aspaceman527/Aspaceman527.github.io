let cars = 1
let driving = false
let player = 1
// will work on skins later
while (driving === true) {
 let harddrivingthing = true
} else {
  let harddrivingthing = false
  }
